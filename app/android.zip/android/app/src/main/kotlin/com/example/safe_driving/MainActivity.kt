package com.example.safe_driving

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
